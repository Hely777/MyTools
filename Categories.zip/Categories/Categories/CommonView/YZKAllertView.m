//
//  YZKAllertView.m
//  Categories
//
//  Created by 佳冬  on 15/10/21.
//  Copyright (c) 2015年 YZK. All rights reserved.
//

#import "YZKAllertView.h"
@interface YZKAllertView()
@property (nonatomic, strong) UIImageView *imageView;
@property (nonatomic, strong) UIView *hud;
@end
@implementation YZKAllertView
-(void)show
{
    
    self.frame = CGRectMake(([UIScreen mainScreen].bounds.size.width - _width) / 2.0, ([UIScreen mainScreen].bounds.size.height - _height) / 2.0, _width, _height);
    [[UIApplication sharedApplication].keyWindow addSubview:self.hud];
    [[UIApplication sharedApplication].keyWindow addSubview:self];
    
    //设置时间
    double delayInSeconds = 0.5;
    //创建一个调度时间,相对于默认时钟或修改现有的调度时间。
    dispatch_time_t delayInNanoSeconds =dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
    //推迟两纳秒执行
    dispatch_queue_t concurrentQueue =dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_after(delayInNanoSeconds, concurrentQueue, ^(void){
        dispatch_async(dispatch_get_main_queue(), ^{
            [self removeFromSuperview];
            [self.hud removeFromSuperview];
         
        });
        
    });
    
    
}
-(instancetype)init
{
    if (self = [super init]){
        [self loadSubViews];
    }
    return self;
}
-(void)loadSubViews
{
    _imageView = [[UIImageView alloc] init];
    [self addSubview:_imageView];
}
-(void)layoutSubviews
{
    _imageView.frame = CGRectMake(0, 0, _width, _height);
}

-(void)setBackgroundImage:(UIImage *)backgroundImage
{
    _backgroundImage = backgroundImage;
    _imageView.image = _backgroundImage;
}
-(UIView *)hud
{
    if (_hud == nil) {
        _hud = [[UIView alloc] initWithFrame:[UIScreen mainScreen].bounds];
        _hud.backgroundColor = [UIColor clearColor];
    }
    return _hud;
}
@end
