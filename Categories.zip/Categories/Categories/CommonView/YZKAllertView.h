//
//  YZKAllertView.h
//  Categories
//
//  Created by 佳冬  on 15/10/21.
//  Copyright (c) 2015年 YZK. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YZKAllertView : UIView
/**
 *  提示框的背景图片
 */
@property (nonatomic, strong) UIImage *backgroundImage;
/**
 *  提示框的高
 */
@property (nonatomic, assign) CGFloat height;
/**
 *  提示框的宽
 */
@property (nonatomic, assign) CGFloat width;
/**
 *  显示提示框
 */
-(void)show;
@end
