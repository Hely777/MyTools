//
//  YZKNavigationController.h
//  Categories
//
//  Created by 佳冬  on 15/10/22.
//  Copyright (c) 2015年 YZK. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YZKNavigationController : UINavigationController

@end
