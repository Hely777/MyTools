//
//  YZKNavigationController.m
//  Categories
//
//  Created by 佳冬  on 15/10/22.
//  Copyright (c) 2015年 YZK. All rights reserved.
//

#import "YZKNavigationController.h"

@interface YZKNavigationController ()

@end

@implementation YZKNavigationController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
//    设置title相关属性
    [self setNavigationBarItem];
    //设置bar的颜色
    self.navigationBar.barTintColor = [UIColor redColor];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    
    
}
-(void)setNavigationBarItem
{
    // 设置普通状态
    // key：NS****AttributeName
    NSMutableDictionary *textAttrs = [NSMutableDictionary dictionary];
    
    //此处设置的颜色、字体为暂时，等需求出来之后在定
    textAttrs[NSForegroundColorAttributeName] = [UIColor redColor];
    textAttrs[NSFontAttributeName] = [UIFont systemFontOfSize:19];
    
    self.navigationBar.titleTextAttributes = textAttrs;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    
    if (self.viewControllers.count > 0) {
        //这时候push进来的控制器不是第一个
        viewController.hidesBottomBarWhenPushed = YES;
        
//        添加leftBarButtonItem  设置按钮图片  点击事件back
       

    }
    [super pushViewController:viewController animated:animated];
    
    
}
-(void)back
{
    [self popViewControllerAnimated:YES];
    
}

@end
