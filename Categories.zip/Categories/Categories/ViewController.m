//
//  ViewController.m
//  Categories
//
//  Created by 佳冬  on 15/10/20.
//  Copyright (c) 2015年 YZK. All rights reserved.
//

#import "ViewController.h"
#import "NSString+YZKExtention.h"
#import "YZKDBTool.h"
#import "YZKAllertView.h"
#import "YZKUserTool.h"
#import "AFNManager.h"
#import "UploadParam.h"
#import <AVFoundation/AVFoundation.h>
@interface ViewController ()<AFNManagerDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    SEL sel=@selector(compare:);
    NSString *functionName= NSStringFromSelector(sel);
    sel_getName(sel);
    
    
//    UploadParam *uploadParam = [[UploadParam alloc] init];
//    uploadParam.fileName = @"jime.jpg";
//    uploadParam.name = @"file";
//    uploadParam.data = UIImageJPEGRepresentation([UIImage imageNamed:@"54f3db62Nb09fba28"], 1.0);
//    uploadParam.mimeType = @"image/jpg";
//    
//    
//    AFNManager *mgr = [AFNManager sharedManager];
//    [mgr Upload:@"http://101.200.189.201/api/file/uploadimg" parameters:@{@"type":
//                                                                              @"1"} uploadParam:uploadParam];
//   
//    NSLog(@"%@", [NSThread mainThread]);
//    mgr.delegate = self;
//    
//    
//    NSLog(@"%@", [NSString pathForLibrary]);
//
//    
    YZKDBTool *tool = [YZKDBTool tool];
    FMDatabase *db = [tool getDBWithDBName:@"db2.sqlite"];
    [tool DataBase:db createTable:@"student2" keyTypes:@{@"name":
                                                          @"text",
                                                      @"age":
                                                           @"integer",
                                                       @"height":
                                                           @"integer"}];

    [tool DataBase:db insertKeyValues:@{@"name":
                                            @"tim",
                                        @"age":
                                            @"22",
                                        @"height":
                                            @"181",
                                        } intoTable:@"student2"];
//
//    
////    NSArray *arr = [tool DataBase:db selectKeysArr:@[@"name", @"age", @"height"] fromTable:@"student2"];
//    NSArray *arr = [tool DataBase:db selectKeyTypes:@{@"name":
//                                                          @"text",
//                                                      @"age":
//                                                          @"integer",
//                                                      @"height":
//                                                          @"integer",
//                                                      @"image":
//                                                          @"blob"} fromTable:@"student2"];
//    NSLog(@"%@", arr);
//    UIImage *image = [UIImage imageWithData:[arr[0] valueForKey:@"image"]];
//
//    UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(100, 100, 100, 100)];
//    imageView.backgroundColor = [UIColor lightGrayColor];
//    imageView.image = image;
//    [self.view addSubview:imageView];
//    
//    
//    
//
//    
//    
////    NSLog(@"++++%@",[arr[0] valueForKey:@"image"]);
//    
//    
////
////    
////    NSArray *arr2 = [tool DataBase:db selectKeysArr:@[@"name", @"age", @"height"] fromTable:@"student2" whereCondition:@{@"name":@"tim"}];
//    
////    [tool clearDatabase:db from:@"student2"];
//    
//    
////    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
////    btn.frame = CGRectMake(100, 100, 100, 100);
////    btn.backgroundColor = [UIColor blueColor];
////    [btn addTarget:self action:@selector(show) forControlEvents:UIControlEventTouchUpInside];
////    [self.view addSubview:btn];
////    
////    
//    YZKUserMessage *user = [[YZKUserMessage alloc] init];
//    user.userName = @"tim";
//    
//    YZKUserTool *userTool = [YZKUserTool tool];
//    userTool.userMessage = user;
//    [userTool storeUserMessage];
//    
//    YZKUserMessage *user2 = [userTool getUserMessage];
//    NSLog(@"%@", user2.userName);
}
-(void)show
{
    YZKAllertView *allert = [[YZKAllertView alloc] init];
    allert.width = 100;
    allert.height = 100;
    allert.backgroundColor = [UIColor redColor];
    [allert show];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}
-(void)AFNManagerDidSuccess:(id)data
{
    
}
-(void)AFNManagerDidFaild:(NSError *)error
{
    
}
@end
