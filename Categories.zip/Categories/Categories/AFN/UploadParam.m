//
//  UploadParam.m
//  Example
//
//  Created by 佳冬  on 15/9/17.
//  Copyright (c) 2015年 mac. All rights reserved.
//

#import "UploadParam.h"

@implementation UploadParam

@end
