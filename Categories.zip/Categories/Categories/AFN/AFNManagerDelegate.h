//
//  AFNManagerDelegate.h
//  Example
//
//  Created by mac on 15/9/17.
//  Copyright (c) 2015年 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
@class AFNManager;

@protocol AFNManagerDelegate <NSObject>

@optional
/**
 *  发送请求成功
 *
 *  @param manager AFNManager
 */
-(void)AFNManagerDidSuccess:(id)data;
/**
 *  发送请求失败
 *
 *  @param manager AFNManager
 */
-(void)AFNManagerDidFaild:(NSError *)error;
@end
