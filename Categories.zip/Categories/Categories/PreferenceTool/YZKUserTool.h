//
//  YZKUserTool.h
//  Categories
//
//  Created by 佳冬  on 15/10/22.
//  Copyright © 2015年 YZK. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "YZKUserMessage.h"
@interface YZKUserTool : NSObject
/**
 *  索要存储的信息
 */
@property (nonatomic, strong) YZKUserMessage *userMessage;
/**
 *  存储信息工具的单例
 *
 *  @return 工具对象
 */
+(YZKUserTool *)tool;
/**
 *  存储信息
 */
-(void)storeUserMessage;
/**
 *  获取信息
 *
 *  @return YZKUserMessage  所获得的信息
 */
-(YZKUserMessage *)getUserMessage;

@end
