//
//  YZKUserTool.m
//  Categories
//
//  Created by 佳冬  on 15/10/22.
//  Copyright © 2015年 YZK. All rights reserved.
//  NSUserdefault  工具  用来存储一些小型数据

#import "YZKUserTool.h"
static YZKUserTool *tool = nil;
@implementation YZKUserTool
+(YZKUserTool *)tool
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (tool == nil) {
            tool = [[self alloc]init];
        }
    });
    return tool;
}
+(instancetype)allocWithZone:(struct _NSZone *)zone
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (tool == nil) {
            tool = [super allocWithZone:zone];
        }
    });
    return tool;
}
-(void)storeUserMessage
{
    NSData *data = [NSKeyedArchiver archivedDataWithRootObject:_userMessage];
    
    NSUserDefaults *user = [NSUserDefaults standardUserDefaults];
    
    [user setObject:data forKey:@"userMessage"];
    
    [user synchronize];
}
-(YZKUserMessage *)getUserMessage
{
    NSUserDefaults *user = [NSUserDefaults standardUserDefaults];
    
    NSData *data = [user objectForKey:@"userMessage"];
    
    YZKUserMessage *userMessage = [NSKeyedUnarchiver unarchiveObjectWithData:data];
    return userMessage;
}
-(void)setUserMessage:(YZKUserMessage *)userMessage
{
    _userMessage = userMessage;
}
@end
